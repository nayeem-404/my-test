# Final K1nG App Entry Point

if __name__ == '__main__':
    print('Launching K1nG Final Analyzer...')